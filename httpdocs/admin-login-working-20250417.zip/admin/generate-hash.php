<?php
echo password_hash('Mackie1974', PASSWORD_DEFAULT);
?>