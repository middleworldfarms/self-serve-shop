// Clean, empty file - we're using CSS for the fix now
// Keeping this file to prevent 404 errors since it's included in index.php