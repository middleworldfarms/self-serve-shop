<?php
require_once '../config.php';

// Ensure the admin is logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: index.php');
    exit;
}

// CSRF token generation
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Initialize variables
$success_message = '';
$error_message = '';
$users = [];

// Database connection
try {
    $db = new PDO('mysql:host=' . DB_HOST . ';dbname=' . DB_NAME, DB_USER, DB_PASS);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Handle user creation
    if (isset($_POST['create_user'])) {
        if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
            die('Invalid CSRF token.');
        }

        $username = $_POST['username'] ?? '';
        $email = $_POST['email'] ?? '';
        $password = $_POST['password'] ?? '';
        $role = $_POST['role'] ?? 'editor';

        if (empty($username) || empty($email) || empty($password)) {
            $error_message = "All fields are required.";
        } elseif (strlen($password) < 8) {
            $error_message = "Password must be at least 8 characters.";
        } else {
            $valid_roles = ['editor', 'administrator'];
            if (!in_array($role, $valid_roles)) {
                $error_message = "Invalid role selected.";
            } else {
                $check = $db->prepare("SELECT ID FROM " . TABLE_PREFIX . "users WHERE user_login = ?");
                $check->execute([$username]);

                if ($check->rowCount() > 0) {
                    $error_message = "Username already exists.";
                } else {
                    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                    $stmt = $db->prepare("
                        INSERT INTO " . TABLE_PREFIX . "users 
                        (user_login, user_pass, user_email, user_registered) 
                        VALUES (?, ?, ?, NOW())
                    ");
                    if ($stmt->execute([$username, $hashed_password, $email])) {
                        $user_id = $db->lastInsertId();
                        $meta_stmt = $db->prepare("
                            INSERT INTO " . TABLE_PREFIX . "usermeta 
                            (user_id, meta_key, meta_value) 
                            VALUES (?, 'wp_capabilities', ?)
                        ");
                        $capabilities = serialize([$role => true]);
                        $meta_stmt->execute([$user_id, $capabilities]);
                        $success_message = "User created successfully.";
                    } else {
                        $error_message = "Failed to create user.";
                    }
                }
            }
        }
    }

    // Handle user editing
    if (isset($_POST['edit_user'])) {
        $edit_user_id = (int)$_POST['edit_user_id'];
        $stmt = $db->prepare("SELECT user_login, user_email FROM " . TABLE_PREFIX . "users WHERE ID = ?");
        $stmt->execute([$edit_user_id]);
        $user_to_edit = $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Handle user update
    if (isset($_POST['update_user'])) {
        $user_id = (int)$_POST['user_id'];
        $username = $_POST['edit_username'] ?? '';
        $email = $_POST['edit_email'] ?? '';
        $password = $_POST['edit_password'] ?? '';

        if (empty($username) || empty($email)) {
            $error_message = "Username and email are required.";
        } else {
            try {
                $stmt = $db->prepare("UPDATE " . TABLE_PREFIX . "users SET user_login = ?, user_email = ? WHERE ID = ?");
                $stmt->execute([$username, $email, $user_id]);

                if (!empty($password)) {
                    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                    $stmt = $db->prepare("UPDATE " . TABLE_PREFIX . "users SET user_pass = ? WHERE ID = ?");
                    $stmt->execute([$hashed_password, $user_id]);
                }

                $success_message = "User updated successfully.";
            } catch (PDOException $e) {
                $error_message = "Database error: " . $e->getMessage();
            }
        }
    }

    // Handle user deletion
    if (isset($_POST['delete_user']) && isset($_POST['user_id'])) {
        if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
            die('Invalid CSRF token.');
        }
        
        $user_id = (int)$_POST['user_id'];
        
        // Prevent deleting the current user
        if ($user_id === $_SESSION['admin_user_id']) {
            $error_message = "You cannot delete your own account while logged in.";
        } else {
            // Delete user
            $stmt = $db->prepare("DELETE FROM " . TABLE_PREFIX . "users WHERE ID = ?");
            $stmt->execute([$user_id]);
            
            // Delete user meta
            $meta_stmt = $db->prepare("DELETE FROM " . TABLE_PREFIX . "usermeta WHERE user_id = ?");
            $meta_stmt->execute([$user_id]);
            
            $success_message = "User deleted successfully.";
        }
    }
    
    // Handle bulk actions
    if (isset($_POST['bulk_action']) && isset($_POST['selected_users']) && !empty($_POST['selected_users'])) {
        if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
            die('Invalid CSRF token.');
        }
        
        $action = $_POST['bulk_action'];
        $selected_users = $_POST['selected_users'];
        
        // Ensure selected_users is an array
        if (!is_array($selected_users)) {
            $selected_users = [$selected_users];
        }
        
        // Sanitize user IDs
        $selected_users = array_map('intval', $selected_users);
        
        try {
            $count = 0;
            if ($action === 'delete') {
                foreach ($selected_users as $user_id) {
                    // Prevent deleting the current user
                    if ($user_id === $_SESSION['admin_user_id']) {
                        continue;
                    }
                    
                    // Delete user
                    $stmt = $db->prepare("DELETE FROM " . TABLE_PREFIX . "users WHERE ID = ?");
                    $stmt->execute([$user_id]);
                    
                    // Delete user meta
                    $meta_stmt = $db->prepare("DELETE FROM " . TABLE_PREFIX . "usermeta WHERE user_id = ?");
                    $meta_stmt->execute([$user_id]);
                    
                    $count++;
                }
                $success_message = $count . " user(s) deleted successfully.";
            } 
            elseif ($action === 'set_admin' || $action === 'set_editor') {
                $role = ($action === 'set_admin') ? 'administrator' : 'editor';
                
                foreach ($selected_users as $user_id) {
                    // Update user role
                    $capabilities = serialize([$role => true]);
                    
                    // Check if user meta exists
                    $check_stmt = $db->prepare("SELECT meta_id FROM " . TABLE_PREFIX . "usermeta 
                                               WHERE user_id = ? AND meta_key = 'wp_capabilities'");
                    $check_stmt->execute([$user_id]);
                    
                    if ($check_stmt->rowCount() > 0) {
                        // Update existing meta
                        $update_stmt = $db->prepare("UPDATE " . TABLE_PREFIX . "usermeta 
                                                   SET meta_value = ? 
                                                   WHERE user_id = ? AND meta_key = 'wp_capabilities'");
                        $update_stmt->execute([$capabilities, $user_id]);
                    } else {
                        // Insert new meta
                        $insert_stmt = $db->prepare("INSERT INTO " . TABLE_PREFIX . "usermeta 
                                                   (user_id, meta_key, meta_value) 
                                                   VALUES (?, 'wp_capabilities', ?)");
                        $insert_stmt->execute([$user_id, $capabilities]);
                    }
                    
                    $count++;
                }
                $role_text = ($action === 'set_admin') ? 'Administrator' : 'Editor';
                $success_message = $count . " user(s) set to " . $role_text . " role successfully.";
            }
        } catch (PDOException $e) {
            $error_message = "Database error: " . $e->getMessage();
        }
    }
    
    // Get all users with pagination
    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    $limit = 10;
    $offset = ($page - 1) * $limit;

    $users_query = $db->prepare("
        SELECT u.ID, u.user_login, u.user_email, u.user_registered, 
               m.meta_value as capabilities
        FROM " . TABLE_PREFIX . "users u
        LEFT JOIN " . TABLE_PREFIX . "usermeta m ON u.ID = m.user_id AND m.meta_key = 'wp_capabilities'
        ORDER BY u.ID ASC
        LIMIT ? OFFSET ?
    ");
    $users_query->bindValue(1, $limit, PDO::PARAM_INT);
    $users_query->bindValue(2, $offset, PDO::PARAM_INT);
    $users_query->execute();
    $users = $users_query->fetchAll(PDO::FETCH_ASSOC);
    
    $total_users = $db->query("SELECT COUNT(*) FROM " . TABLE_PREFIX . "users")->fetchColumn();
    $total_pages = ceil($total_users / $limit);

    echo '<div class="pagination">';
    for ($i = 1; $i <= $total_pages; $i++) {
        echo '<a href="?page=' . $i . '">' . $i . '</a> ';
    }
    echo '</div>';
    
} catch (PDOException $e) {
    error_log("Database error: " . $e->getMessage() . " in query: " . $stmt->queryString, 3, '/var/log/php_errors.log');
    echo '<p style="color:red;">Database error occurred. Please try again later.</p>';
}

// Function to get user role from capabilities
function get_user_role($capabilities) {
    if (empty($capabilities)) return 'No role assigned';
    
    $unserialized = @unserialize($capabilities);
    if ($unserialized === false) return 'Invalid role data';
    
    return key($unserialized) ?? 'No role assigned';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Users - Self-Serve Shop Admin</title>
    <link rel="stylesheet" href="../css/styles.css">
    <style>
        .admin-container {
            max-width: 1000px;
            margin: 0 auto;
            padding: 2rem;
            background-color: white;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }
        
        .success-message {
            background-color: #d4edda;
            color: #155724;
            padding: 1rem;
            border-radius: 4px;
            margin-bottom: 1rem;
        }
        
        .error-message {
            background-color: #f8d7da;
            color: #721c24;
            padding: 1rem;
            border-radius: 4px;
            margin-bottom: 1rem;
        }
        
        .users-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 1rem;
        }
        
        .users-table th,
        .users-table td {
            padding: 0.75rem;
            text-align: left;
            border-bottom: 1px solid #eee;
        }
        
        .users-table th {
            background-color: #f9f9f9;
            font-weight: bold;
        }
        
        .create-user-form {
            margin-top: 2rem;
            padding-top: 1rem;
            border-top: 1px solid #eee;
        }
        
        .form-section {
            margin-bottom: 1.5rem;
        }
    </style>
    <!-- Add this CSS before the users table -->
    <style>
        .users-table {
            font-size: 0.9rem; /* Reduce text size */
            width: 100%;
            border-collapse: collapse;
        }
        
        .users-table th,
        .users-table td {
            padding: 8px; /* Slightly reduced padding */
            border: 1px solid #ddd;
            text-align: left;
        }
        
        .users-table th {
            background-color: #f5f5f5;
            font-weight: bold;
        }
        
        .users-table tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        
        .users-table tr:hover {
            background-color: #f1f1f1;
        }
        
        .delete-button {
            padding: 4px 8px; /* Smaller button */
            background-color: #dc3545;
            color: white;
            border: none;
            border-radius: 3px;
            cursor: pointer;
            font-size: 0.8rem; /* Smaller button text */
        }
        
        .delete-button:hover {
            background-color: #c82333;
        }
    </style>
    <!-- Add this CSS before the create user form section -->
    <style>
        /* Existing CSS remains... */
        
        /* New user form styling */
        .new-user-form {
            background-color: #f9f9f9;
            padding: 20px;
            border-radius: 5px;
            margin-top: 30px;
        }
        
        .form-row {
            display: flex;
            align-items: center;
            margin-bottom: 15px;
        }
        
        .form-row label {
            width: 120px; /* Fixed width for labels */
            margin-right: 15px; /* Space between label and input */
            text-align: right; /* Right-align the labels */
        }
        
        .form-row input[type="text"],
        .form-row input[type="email"],
        .form-row input[type="password"],
        .form-row select {
            flex: 1; /* Take up remaining space */
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
            max-width: 300px; /* Limit maximum width */
        }
        
        .form-submit {
            margin-top: 20px;
            margin-left: 135px; /* Aligns with inputs (120px + 15px) */
        }
        
        .form-submit button {
            padding: 10px 15px; /* Adjust padding for a larger button */
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 4px; /* Rounded corners */
            cursor: pointer;
            width: 100%; /* Make the button take up the full width of the form */
            font-size: 1rem; /* Ensure the text size is consistent */
            text-align: center; /* Center the text */
        }
        
        .form-submit button:hover {
            background-color: #45a049; /* Slightly darker green on hover */
        }
    </style>
    <!-- Add this CSS to the head section: -->
    <style>
        .admin-header {
            background-color: #4CAF50; /* Green background to match settings.php */
            color: white;
            padding: 15px 0;
            margin-bottom: 20px;
            position: relative; /* Allow absolute positioning of children */
        }

        .header-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            width: 100%;
            padding: 0 20px;
            max-width: 1200px;
            margin: 0 auto;
            text-align: center; /* Center text within header */
        }

        .header-left {
            display: flex;
            align-items: center;
            gap: 20px;
            flex: 1; /* Take up available space */
            justify-content: center; /* Center the title and link */
        }

        .header-left h1 {
            margin: 0;
            color: white;
            font-size: 24px;
            text-align: center; /* Center the title text */
        }

        /* Position the back link to the left edge */
        .back-link {
            position: absolute;
            left: 20px;
        }

        /* Position the logout link to the right edge */
        .logout-link {
            position: absolute;
            right: 20px;
        }
    </style>
    <!-- Add these CSS rules to the style section in manage-users.php -->
    <style>
        .admin-layout {
            position: relative;
            display: block;
            clear: both;
        }

        .sidebar {
            float: left;
            width: 250px;
            background-color: #f8f9fa;
            border-radius: 8px;
            padding: 10px 20px 20px 20px; /* Reduce top padding to 10px */
            margin-right: 20px;
            margin-left: -10px; /* Move the sidebar closer to the left edge */
        }

        .main-content {
            margin-left: 280px; /* Ensure alignment with the sidebar (300px width + 20px margin-right) */
        }

        /* Add this to ensure proper clearing of floats */
        .admin-layout:after {
            content: "";
            display: table;
            clear: both;
        }

        .sidebar-section {
            background-color: white;
            padding: 15px;
            border-radius: 5px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 25px;
        }

        .sidebar-section h3 {
            margin-top: 0;
            font-size: 16px;
            border-bottom: 1px solid #eee;
            padding-bottom: 10px;
            margin-bottom: 15px;
        }

        /* Make buttons in sidebar full width */
        .sidebar .button {
            width: 100%;
            text-align: center;
            margin-top: 10px;
            margin-bottom: 10px;
        }

        .add-user-button {
            position: relative;
            top: -23px; /* Move the button up by 40px */
            margin-bottom: 35px; /* Space below the button */
            background-color: #4CAF50;
            color: white;
            font-weight: bold;
            padding: 12px 15px;
            display: block;
            text-align: center;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .add-user-button:hover {
            background-color: #45a049;
        }

        .bulk-actions-sidebar {
            padding-top: 15px;
        }

        .bulk-actions-sidebar .button {
            margin-top: 15px;
        }

        .select-all-container {
            margin: 10px 0;
        }
    </style>
    <style>
        .edit-user-form {
            background-color: #f9f9f9;
            padding: 20px;
            border-radius: 5px;
            margin-top: 20px;
        }

        .edit-user-form h3 {
            margin-top: 0;
        }

        .edit-user-form .form-row {
            margin-bottom: 15px;
        }

        .edit-user-form label {
            display: block;
            margin-bottom: 5px;
        }

        .edit-user-form input[type="text"],
        .edit-user-form input[type="email"],
        .edit-user-form input[type="password"] {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }

        .edit-user-form button {
            background-color: #4CAF50;
            color: white;
            padding: 10px 10px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            width: 100%; /* Make the button take up the full width of the form */
            font-size: 1rem; /* Ensure the text size is consistent */
            text-align: center; /* Center the text */
        }

        .edit-user-form button:hover {
            background-color: #45a049;
        }
    </style>
    <style>
        .delete-button {
            background-color: #dc3545; /* Red background */
            color: white;
            padding: 10px 15px; /* Match the padding of the Edit button */
            border: none;
            border-radius: 4px; /* Match the border radius of the Edit button */
            cursor: pointer;
            font-size: 1rem; /* Match the font size of the Edit button */
        }

        .delete-button:hover {
            background-color: #c82333; /* Slightly darker red on hover */
        }
    </style>
    <style>
        .action-button {
            padding: 6px 10px; /* Adjusted padding for smaller size */
            background-color: #4CAF50; /* Default green background */
            color: white;
            border: none;
            border-radius: 4px; /* Rounded corners */
            cursor: pointer;
            font-size: 0.8rem; /* Slightly smaller font size */
            display: inline-block; /* Prevent buttons from stretching */
            text-align: center; /* Ensure text is centered */
            width: 50px; /* Reduced width to half the original size */
            box-sizing: border-box; /* Include padding in width */
        }

        .action-button:hover {
            background-color: #45a049; /* Slightly darker green on hover */
        }

        .delete-button {
            background-color: #dc3545; /* Red background for delete */
        }

        .delete-button:hover {
            background-color: #c82333; /* Slightly darker red on hover */
        }
    </style>
</head>
<body>
    <header class="admin-header">
        <div class="header-container">
            <div class="header-left">
                <h1>Manage Users</h1>
                <a href="index.php" class="back-link">Return to Dashboard</a>
            </div>
            <div class="header-right">
                <a href="?logout=1" class="logout-link">Logout</a>
            </div>
        </div>
    </header>
    
    <main>
        <div class="admin-container">
            <h2>Manage Users</h2>
            
            <?php if (!empty($success_message)): ?>
            <div class="success-message">
                <?php echo $success_message; ?>
            </div>
            <?php endif; ?>
            
            <?php if (!empty($error_message)): ?>
            <div class="error-message">
                <?php echo $error_message; ?>
            </div>
            <?php endif; ?>
            
            <div class="admin-layout">
                <form method="post" action="" id="bulk-form">
                    <!-- Sidebar -->
                    <div class="sidebar">
                        <button type="button" class="button add-user-button" onclick="toggleNewUserForm()">+ Add New User</button>
                        
                        <!-- Bulk actions in sidebar -->
                        <div class="sidebar-section">
                            <h3>Bulk Actions</h3>
                            <div class="bulk-actions-sidebar">
                                <div>
                                    <label for="bulk_action">Action:</label>
                                    <select id="bulk_action" name="bulk_action" style="width: 100%;">
                                        <option value="">Choose an action...</option>
                                        <option value="set_admin">Set as Administrator</option>
                                        <option value="set_editor">Set as Editor</option>
                                        <option value="delete">Delete</option>
                                    </select>
                                </div>
                                
                                <div class="select-all-container">
                                    <input type="checkbox" id="select_all" onclick="toggleSelectAll(this)">
                                    <label for="select_all">Select All</label>
                                </div>
                                
                                <button type="submit" class="button">Apply</button>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Main content -->
                    <div class="main-content">
                        <table class="users-table">
                            <thead>
                                <tr>
                                    <th>Select</th>
                                    <th>ID</th>
                                    <th>Username</th>
                                    <th>Email</th>
                                    <th>Role</th>
                                    <th>Registered</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($users as $user): ?>
                                <tr>
                                    <td><input type="checkbox" name="selected_users[]" value="<?php echo $user['ID']; ?>" class="user-checkbox"></td>
                                    <td><?php echo $user['ID']; ?></td>
                                    <td><?php echo htmlspecialchars($user['user_login']); ?></td>
                                    <td><?php echo htmlspecialchars($user['user_email']); ?></td>
                                    <td><?php echo get_user_role($user['capabilities']); ?></td>
                                    <td><?php echo $user['user_registered']; ?></td>
                                    <td>
                                        <form method="post" action="" style="display:inline;">
                                            <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                                            <input type="hidden" name="edit_user_id" value="<?php echo $user['ID']; ?>">
                                            <button type="submit" name="edit_user" class="action-button">Edit</button>
                                        </form>
                                        <form method="post" action="" style="display:inline;">
                                            <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                                            <input type="hidden" name="user_id" value="<?php echo $user['ID']; ?>">
                                            <button type="submit" name="delete_user" class="action-button delete-button" onclick="return confirm('Are you sure?');">Delete</button>
                                        </form>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                        
                        <!-- Create user form -->
                        <div class="create-user-form new-user-form" id="new-user-form" style="display:none;">
                            <h3>Create New User</h3>
                            <form method="post" action="">
                                <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                                <div class="form-row">
                                    <label for="username">Username:</label>
                                    <input type="text" id="username" name="username" required>
                                </div>
                                <div class="form-row">
                                    <label for="email">Email:</label>
                                    <input type="email" id="email" name="email" required>
                                </div>
                                <div class="form-row">
                                    <label for="password">Password:</label>
                                    <input type="password" id="password" name="password" required>
                                    <span id="password-strength"></span>
                                </div>
                                <div class="form-row">
                                    <label for="role">Role:</label>
                                    <select id="role" name="role">
                                        <option value="editor">Editor</option>
                                        <option value="administrator">Administrator</option>
                                    </select>
                                </div>
                                <div class="form-submit">
                                    <button type="submit" name="create_user" class="action-button">Create User</button>
                                </div>
                            </form>
                        </div>

                        <!-- Edit user form -->
                        <?php if (isset($user_to_edit)): ?>
                        <div class="edit-user-form">
                            <h3>Edit User</h3>
                            <form method="post" action="">
                                <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                                <input type="hidden" name="user_id" value="<?php echo $edit_user_id; ?>">
                                <div class="form-row">
                                    <label for="edit_username">Username:</label>
                                    <input type="text" id="edit_username" name="edit_username" value="<?php echo htmlspecialchars($user_to_edit['user_login']); ?>" required>
                                </div>
                                <div class="form-row">
                                    <label for="edit_email">Email:</label>
                                    <input type="email" id="edit_email" name="edit_email" value="<?php echo htmlspecialchars($user_to_edit['user_email']); ?>" required>
                                </div>
                                <div class="form-row">
                                    <label for="edit_password">Password (leave blank to keep current):</label>
                                    <input type="password" id="edit_password" name="edit_password">
                                </div>
                                <button type="submit" name="update_user" class="action-button">Update User</button>
                            </form>
                        </div>
                        <?php endif; ?>
                    </div>
                </form>
            </div>
        </div>
    </main>
    
    <script>
        function toggleNewUserForm() {
            var form = document.getElementById('new-user-form');
            form.style.display = (form.style.display === 'none' || form.style.display === '') ? 'block' : 'none';
        }
        
        function toggleSelectAll(checkbox) {
            var checkboxes = document.querySelectorAll('input[name="selected_users[]"]');
            checkboxes.forEach(function(cb) {
                cb.checked = checkbox.checked;
            });
        }

        document.getElementById('select-all').addEventListener('change', function() {
            var checkboxes = document.querySelectorAll('.user-checkbox');
            checkboxes.forEach(function(checkbox) {
                checkbox.checked = document.getElementById('select-all').checked;
            });
        });

        // Update "Select All" checkbox state when individual checkboxes are toggled
        document.querySelectorAll('.user-checkbox').forEach(function(checkbox) {
            checkbox.addEventListener('change', function() {
                var allChecked = Array.from(document.querySelectorAll('.user-checkbox')).every(function(cb) {
                    return cb.checked;
                });
                document.getElementById('select-all').checked = allChecked;
            });
        });

        document.getElementById('password').addEventListener('input', function() {
            var strength = document.getElementById('password-strength');
            var value = this.value;

            if (value.length < 8) {
                strength.textContent = 'Weak';
                strength.style.color = 'red';
            } else if (value.match(/[A-Z]/) && value.match(/[0-9]/)) {
                strength.textContent = 'Strong';
                strength.style.color = 'green';
            } else {
                strength.textContent = 'Moderate';
                strength.style.color = 'orange';
            }
        });
    </script>
</body>
</html>