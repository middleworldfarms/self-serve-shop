<?php
// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Admin authentication check
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: index.php');
    exit;
}

// Add CSRF protection
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

require_once '../config.php';

// Ensure database connection is established
try {
    // Create database connection if not already exists
    if (!isset($db)) {
        $db = new PDO(
            'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME, 
            DB_USER, 
            DB_PASS
        );
        $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Add this after your database connection code
$db->query("USE " . DB_NAME);

// Check if users table exists and create it if needed
try {
    $result = $db->query("SHOW TABLES LIKE 'users'");
    $tableExists = ($result->rowCount() > 0);
    
    if (!$tableExists) {
        // Create users table
        $db->exec("
            CREATE TABLE IF NOT EXISTS users (
                id INT AUTO_INCREMENT PRIMARY KEY,
                username VARCHAR(50) NOT NULL UNIQUE,
                email VARCHAR(100) NOT NULL,
                password VARCHAR(255) NOT NULL,
                role VARCHAR(20) NOT NULL DEFAULT 'admin',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ");
        
        // Insert default admin user
        $stmt = $db->prepare("INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)");
        $stmt->execute([
            'admin',
            'admin@example.com',
            password_hash('admin123', PASSWORD_DEFAULT), // Default password: admin123
            'admin'
        ]);
        
        error_log("Users table created with default admin user.");
    }
} catch (PDOException $e) {
    error_log("Error creating users table: " . $e->getMessage());
}

// Replace the existing table creation code with this:
try {
    // Check if orders table exists
    $result = $db->query("SHOW TABLES LIKE 'orders'");
    $ordersTableExists = ($result->rowCount() > 0);
    
    if (!$ordersTableExists) {
        // Create orders table
        $db->exec("
            CREATE TABLE IF NOT EXISTS `orders` (
                `id` INT AUTO_INCREMENT PRIMARY KEY,
                `order_number` VARCHAR(50) NOT NULL,
                `customer_name` VARCHAR(100),
                `customer_email` VARCHAR(100),
                `total_amount` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
                `payment_method` VARCHAR(50),
                `payment_status` VARCHAR(30) DEFAULT 'pending',
                `order_status` VARCHAR(30) DEFAULT 'new',
                `order_notes` TEXT,
                `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
        error_log("Orders table created successfully.");
        
        // Insert a sample order for testing
        $db->exec("
            INSERT INTO `orders` 
            (`order_number`, `customer_name`, `customer_email`, `total_amount`, `payment_method`, `payment_status`, `order_status`) 
            VALUES 
            ('ORD-001', 'Test Customer', 'test@example.com', 25.00, 'Manual', 'completed', 'completed')
        ");
    }
    
    // Check if order_logs table exists
    $result = $db->query("SHOW TABLES LIKE 'order_logs'");
    $logsTableExists = ($result->rowCount() > 0);
    
    if (!$logsTableExists) {
        // Create order_logs table WITH NO FOREIGN KEY initially
        $db->exec("
            CREATE TABLE IF NOT EXISTS `order_logs` (
                `id` INT AUTO_INCREMENT PRIMARY KEY,
                `order_id` INT NULL,
                `log_type` VARCHAR(30) NOT NULL,
                `message` TEXT NOT NULL,
                `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
        
        // Add a sample log entry
        $db->exec("
            INSERT INTO `order_logs` (`log_type`, `message`) 
            VALUES ('system', 'Order logs system initialized')
        ");
        
        // Add more sample entries
        $db->exec("
            INSERT INTO `order_logs` (`order_id`, `log_type`, `message`) 
            VALUES (1, 'payment', 'Payment received via Manual payment')
        ");
        
        $db->exec("
            INSERT INTO `order_logs` (`log_type`, `message`) 
            VALUES ('system', 'Shop settings updated')
        ");
        
        error_log("Order_logs table created with sample entries.");
    }
} catch (PDOException $e) {
    error_log("Error creating order tables: " . $e->getMessage());
}

// Set the page title for the header
$page_title = "Settings";

// Include the header (this should include navigation and top part of the layout)
include 'includes/header.php';

// Functions for settings
function get_settings() {
    global $db;
    $settings = [];
    
    // Get settings from database
    $stmt = $db->query("SELECT setting_name, setting_value FROM self_serve_settings");
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $settings[$row['setting_name']] = $row['setting_value'];
    }
    
    // Set defaults for missing settings
    $default_settings = [
        'shop_name' => 'Self-Serve Shop',
        'shop_organization' => 'Your Organization',
        'currency_symbol' => '$',
        'primary_color' => '#4CAF50',
        'secondary_color' => '#388E3C',
        'background_color' => '#f5f5f5',
        'text_color' => '#333333',
        'header_text' => 'Welcome to our Self-Serve Shop',
        'footer_text' => '&copy; ' . date('Y') . ' Your Organization',
        'custom_header' => '',
        'custom_footer' => '',
        'shop_description' => 'A convenient self-serve shop for our customers.',
        'custom_css' => '',
        'enable_manual_payment' => '1',
        'payment_instructions' => 'Please leave cash in the box or use one of our electronic payment options.',
    ];
    
    foreach ($default_settings as $key => $value) {
        if (!isset($settings[$key])) {
            $settings[$key] = $value;
        }
    }
    
    return $settings;
}

function save_settings($settings) {
    global $db;
    
    try {
        $db->beginTransaction();
        
        foreach ($settings as $name => $value) {
            // Check if setting exists
            $stmt = $db->prepare("SELECT COUNT(*) FROM self_serve_settings WHERE setting_name = ?");
            $stmt->execute([$name]);
            $exists = (bool)$stmt->fetchColumn();
            
            if ($exists) {
                // Update existing setting
                $stmt = $db->prepare("UPDATE self_serve_settings SET setting_value = ? WHERE setting_name = ?");
                $stmt->execute([$value, $name]);
            } else {
                // Insert new setting
                $stmt = $db->prepare("INSERT INTO self_serve_settings (setting_name, setting_value) VALUES (?, ?)");
                $stmt->execute([$name, $value]);
            }
        }
        
        $db->commit();
        return true;
    } catch (PDOException $e) {
        $db->rollBack();
        error_log("Settings save error: " . $e->getMessage());
        return false;
    }
}

// Helper function to show color preview
function color_preview($color) {
    return "<div style='display: inline-block; width: 20px; height: 20px; background-color: {$color}; border: 1px solid #ddd; vertical-align: middle; margin-left: 5px;'></div>";
}

// User management functions
function add_user($username, $email, $password, $role) {
    global $db;
    
    try {
        // Hash the password
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        
        // Insert the user
        $stmt = $db->prepare("INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)");
        $stmt->execute([$username, $email, $hashed_password, $role]);
        
        return true;
    } catch (PDOException $e) {
        error_log("Error adding user: " . $e->getMessage());
        return false;
    }
}

// Process form submission
$message = '';
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    error_log('Form submitted: ' . print_r($_POST, true));
    
    // Add user
    if (isset($_POST['action']) && $_POST['action'] === 'add_user') {
        if (isset($_POST['new_username'], $_POST['new_email'], $_POST['new_password'], $_POST['new_role'])) {
            $username = $_POST['new_username'];
            $email = $_POST['new_email'];
            $password = $_POST['new_password'];
            $role = $_POST['new_role'];
            
            if (add_user($username, $email, $password, $role)) {
                $message = "User added successfully.";
            } else {
                $error = "Error adding user. Please try again.";
            }
            
            // Set the active tab to users
            $active_tab = 'users';
        }
    }
    
    // Process settings form
    if (isset($_POST['save_settings'])) {
        error_log('Save settings button clicked');
        // Collect all settings from the form
        $settings = [
            'shop_name' => $_POST['shop_name'] ?? '',
            'shop_organization' => $_POST['shop_organization'] ?? '',
            'currency_symbol' => $_POST['currency_symbol'] ?? '$',
            'primary_color' => $_POST['primary_color'] ?? '#4CAF50',
            'secondary_color' => $_POST['secondary_color'] ?? '#388E3C',
            'background_color' => $_POST['background_color'] ?? '#f5f5f5',
            'text_color' => $_POST['text_color'] ?? '#333333',
            'header_text' => $_POST['header_text'] ?? '',
            'footer_text' => $_POST['footer_text'] ?? '',
            'custom_header' => $_POST['custom_header'] ?? '',
            'custom_footer' => $_POST['custom_footer'] ?? '',
            'shop_description' => $_POST['shop_description'] ?? '',
            'custom_css' => $_POST['custom_css'] ?? '',
            'enable_manual_payment' => isset($_POST['enable_manual_payment']) ? '1' : '0',
            'payment_instructions' => $_POST['payment_instructions'] ?? '',
            'enable_stripe_payment' => isset($_POST['enable_stripe_payment']) ? '1' : '0',
            'stripe_public_key' => $_POST['stripe_public_key'] ?? '',
            'stripe_secret_key' => $_POST['stripe_secret_key'] ?? '',
            'stripe_webhook_secret' => $_POST['stripe_webhook_secret'] ?? '',
            'enable_paypal_payment' => isset($_POST['enable_paypal_payment']) ? '1' : '0',
            'paypal_client_id' => $_POST['paypal_client_id'] ?? '',
            'paypal_secret' => $_POST['paypal_secret'] ?? '',
            'enable_bank_transfer' => isset($_POST['enable_bank_transfer']) ? '1' : '0',
            'bank_details' => $_POST['bank_details'] ?? '',
            'enable_woo_funds_payment' => isset($_POST['enable_woo_funds_payment']) ? '1' : '0',
            'woocommerce_site_url' => $_POST['woocommerce_site_url'] ?? '',
            'woo_funds_api_key' => $_POST['woo_funds_api_key'] ?? '',
            'enable_gocardless_payment' => isset($_POST['enable_gocardless_payment']) ? '1' : '0',
            'gocardless_access_token' => $_POST['gocardless_access_token'] ?? '',
            'gocardless_environment' => $_POST['gocardless_environment'] ?? 'sandbox',
            'gocardless_webhook_secret' => $_POST['gocardless_webhook_secret'] ?? '',
            'enable_apple_google_pay' => isset($_POST['enable_apple_google_pay']) ? '1' : '0',
            'apple_merchant_id' => $_POST['apple_merchant_id'] ?? '',
            'google_merchant_id' => $_POST['google_merchant_id'] ?? '',
            'shop_url' => $_POST['shop_url'] ?? '',
        ];
        
        // Handle logo upload
        if (isset($_FILES['shop_logo']) && $_FILES['shop_logo']['error'] === 0) {
            $uploadDir = "../uploads/logos/";
            
            // Create directory if it doesn't exist
            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0755, true);
            }
            
            $fileName = basename($_FILES["shop_logo"]["name"]);
            $targetFilePath = $uploadDir . 'logo_' . time() . '_' . uniqid() . '_' . $fileName;
            
            $fileType = pathinfo($targetFilePath, PATHINFO_EXTENSION);
            
            // Allow certain file formats
            $allowTypes = array('jpg','png','jpeg','gif');
            if(in_array(strtolower($fileType), $allowTypes)){
                // Upload file to server
                if(move_uploaded_file($_FILES["shop_logo"]["tmp_name"], $targetFilePath)){
                    $relativePath = str_replace("../", "", $targetFilePath);
                    $settings['shop_logo'] = $relativePath;
                } else {
                    $error = "Sorry, there was an error uploading your file.";
                }
            } else {
                $error = "Sorry, only JPG, JPEG, PNG, & GIF files are allowed.";
            }
        }
        
        // For logo uploads
        if (isset($_FILES['shop_logo']) && $_FILES['shop_logo']['error'] === 0) {
            $uploadDir = "uploads/"; // This is relative to admin/ directory
            
            // Create directory if it doesn't exist
            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0755, true);
            }
            
            $fileName = basename($_FILES["shop_logo"]["name"]);
            $targetFilePath = $uploadDir . 'logo_' . time() . '_' . uniqid() . '_' . $fileName;
            
            // Upload file and set path
            if (move_uploaded_file($_FILES["shop_logo"]["tmp_name"], $targetFilePath)) {
                $settings['shop_logo'] = '/admin/uploads/' . basename($targetFilePath);
            }
        }
        
        // Save settings
        if (save_settings($settings)) {
            $message = "Settings updated successfully.";
        } else {
            $error = "Error saving settings. Please try again.";
        }
    }
}

// Get current settings
$current_settings = get_settings();

// Handle tab switching
$active_tab = 'general'; // Default tab
if (isset($_GET['tab'])) {
    $allowed_tabs = ['general', 'branding', 'payment', 'content', 'users', 'order_logs'];
    if (in_array($_GET['tab'], $allowed_tabs)) {
        $active_tab = $_GET['tab'];
    }
}
?>

<div class="admin-container">
    <h2>Shop Settings</h2>
        
    <?php if (!empty($message)): ?>
    <div class="success-message">
        <?php echo $message; ?>
    </div>
    <?php endif; ?>
    
    <?php if (!empty($error)): ?>
    <div class="error-message">
        <?php echo $error; ?>
    </div>
    <?php endif; ?>
    
    <div class="settings-content">
        <!-- Tab Navigation -->
        <div class="settings-tabs">
            <a href="?tab=general" class="settings-tab <?php echo ($active_tab == 'general') ? 'active' : ''; ?>">General</a>
            <a href="?tab=branding" class="settings-tab <?php echo ($active_tab == 'branding') ? 'active' : ''; ?>">Branding</a>
            <a href="?tab=payment" class="settings-tab <?php echo ($active_tab == 'payment') ? 'active' : ''; ?>">Payment</a>
            <a href="?tab=content" class="settings-tab <?php echo ($active_tab == 'content') ? 'active' : ''; ?>">Content</a>
            <a href="?tab=users" class="settings-tab <?php echo ($active_tab == 'users') ? 'active' : ''; ?>">Users</a>
            <a href="?tab=order_logs" class="settings-tab <?php echo ($active_tab == 'order_logs') ? 'active' : ''; ?>">Order Logs</a>
        </div>

        <!-- Tab Contents -->
        <form method="post" action="" enctype="multipart/form-data">
            <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
            
            <!-- General Tab -->
            <div id="general-tab" class="tab-content <?php echo ($active_tab == 'general') ? 'active' : ''; ?>">
                <h3>General Settings</h3>
                
                <div class="settings-section">
                    <h4>Shop Information</h4>
                    <div class="form-row">
                        <label for="shop_name">Shop Name:</label>
                        <input type="text" id="shop_name" name="shop_name" value="<?php echo htmlspecialchars($current_settings['shop_name'] ?? ''); ?>">
                    </div>
                    
                    <!-- Other general settings fields -->
                </div>
            </div>
            
            <!-- Branding Tab -->
            <div id="branding-tab" class="tab-content <?php echo ($active_tab == 'branding') ? 'active' : ''; ?>">
                <h3>Branding Settings</h3>
                <div class="form-row">
                    <label for="shop_logo">Shop Logo:</label>
                    <input type="file" id="shop_logo" name="shop_logo" accept="image/*">
                    <small>Recommended size: 300px × 300px</small>
                </div>
                <?php if (!empty($current_settings['shop_logo'])): ?>
                <div class="current-logo">
                    <p>Current logo:</p>
                    <img src="../<?php echo htmlspecialchars($current_settings['shop_logo']); ?>" alt="Current Logo" style="max-height: 100px;">
                </div>
                <?php endif; ?>
                <div class="form-row">
                    <label for="primary_color">Primary Color:</label>
                    <div class="color-input-group">
                        <input type="color" id="primary_color" name="primary_color" class="color-picker" 
                              value="<?php echo htmlspecialchars($current_settings['primary_color']); ?>">
                        <input type="text" value="<?php echo htmlspecialchars($current_settings['primary_color']); ?>" 
                              class="color-value" data-for="primary_color">
                        <div class="color-preview" style="background-color: <?php echo htmlspecialchars($current_settings['primary_color']); ?>"></div>
                    </div>
                    <small>Main color for buttons and accents</small>
                </div>
                <div class="form-row">
                    <label for="secondary_color">Secondary Color:</label>
                    <div class="color-input-group">
                        <input type="color" id="secondary_color" name="secondary_color" class="color-picker" 
                              value="<?php echo htmlspecialchars($current_settings['secondary_color']); ?>">
                        <input type="text" value="<?php echo htmlspecialchars($current_settings['secondary_color']); ?>" 
                              class="color-value" data-for="secondary_color">
                        <div class="color-preview" style="background-color: <?php echo htmlspecialchars($current_settings['secondary_color']); ?>"></div>
                    </div>
                    <small>Used for borders and secondary elements</small>
                </div>
                <div class="form-row">
                    <label for="background_color">Background Color:</label>
                    <div class="color-input-group">
                        <input type="color" id="background_color" name="background_color" class="color-picker" 
                              value="<?php echo htmlspecialchars($current_settings['background_color']); ?>">
                        <input type="text" value="<?php echo htmlspecialchars($current_settings['background_color']); ?>" 
                              class="color-value" data-for="background_color">
                        <div class="color-preview" style="background-color: <?php echo htmlspecialchars($current_settings['background_color']); ?>"></div>
                    </div>
                    <small>Background color for the shop</small>
                </div>
                <div class="form-row">
                    <label for="text_color">Text Color:</label>
                    <div class="color-input-group">
                        <input type="color" id="text_color" name="text_color" class="color-picker" 
                              value="<?php echo htmlspecialchars($current_settings['text_color']); ?>">
                        <input type="text" value="<?php echo htmlspecialchars($current_settings['text_color']); ?>" 
                              class="color-value" data-for="text_color">
                        <div class="color-preview" style="background-color: <?php echo htmlspecialchars($current_settings['text_color']); ?>"></div>
                    </div>
                    <small>Main text color</small>
                </div>
            </div>
            
            <!-- Payment Tab -->
            <div id="payment-tab" class="tab-content <?php echo ($active_tab == 'payment') ? 'active' : ''; ?>">
                <h3>Payment Settings</h3>
                
                <div class="form-row">
                    <label>Available Payment Methods:</label>
                    <div class="checkbox-group">
                        <!-- Manual Payment -->
                        <div class="checkbox-item">
                            <input type="checkbox" id="enable_manual" name="enable_manual_payment" value="1" 
                                   <?php echo (isset($current_settings['enable_manual_payment']) && $current_settings['enable_manual_payment'] == '1') ? 'checked' : ''; ?>>
                            <label for="enable_manual">Honor Box / Manual Payment</label>
                        </div>
                        
                        <!-- Stripe -->
                        <div class="checkbox-item">
                            <input type="checkbox" id="enable_stripe" name="enable_stripe_payment" value="1"
                                   <?php echo (isset($current_settings['enable_stripe_payment']) && $current_settings['enable_stripe_payment'] == '1') ? 'checked' : ''; ?>>
                            <label for="enable_stripe">Stripe</label>
                        </div>
                        
                        <!-- PayPal -->
                        <div class="checkbox-item">
                            <input type="checkbox" id="enable_paypal" name="enable_paypal_payment" value="1"
                                   <?php echo (isset($current_settings['enable_paypal_payment']) && $current_settings['enable_paypal_payment'] == '1') ? 'checked' : ''; ?>>
                            <label for="enable_paypal">PayPal</label>
                        </div>
                        
                        <!-- Bank Transfer -->
                        <div class="checkbox-item">
                            <input type="checkbox" id="enable_bank_transfer" name="enable_bank_transfer" value="1"
                                   <?php echo (isset($current_settings['enable_bank_transfer']) && $current_settings['enable_bank_transfer'] == '1') ? 'checked' : ''; ?>>
                            <label for="enable_bank_transfer">Bank Transfer</label>
                        </div>
                        
                        <!-- WooCommerce Funds -->
                        <div class="checkbox-item">
                            <input type="checkbox" id="enable_woo_funds" name="enable_woo_funds_payment" value="1"
                                   <?php echo (isset($current_settings['enable_woo_funds_payment']) && $current_settings['enable_woo_funds_payment'] == '1') ? 'checked' : ''; ?>>
                            <label for="enable_woo_funds">WooCommerce Funds</label>
                        </div>
                        
                        <!-- GoCardless -->
                        <div class="checkbox-item">
                            <input type="checkbox" id="enable_gocardless" name="enable_gocardless_payment" value="1"
                                   <?php echo (isset($current_settings['enable_gocardless_payment']) && $current_settings['enable_gocardless_payment'] == '1') ? 'checked' : ''; ?>>
                            <label for="enable_gocardless">GoCardless (Direct Debit)</label>
                        </div>
                        
                        <!-- Apple/Google Pay -->
                        <div class="checkbox-item">
                            <input type="checkbox" id="enable_apple_google" name="enable_apple_google_pay" value="1"
                                   <?php echo (isset($current_settings['enable_apple_pay_payment']) && $current_settings['enable_apple_pay_payment'] == '1') ? 'checked' : ''; ?>>
                            <label for="enable_apple_google">Apple Pay / Google Pay</label>
                        </div>
                    </div>
                </div>
                
                <!-- Manual Payment Section -->
                <div id="manual-payment-section" class="conditional-section" style="display: <?php echo (isset($current_settings['enable_manual_payment']) && $current_settings['enable_manual_payment'] == '1') ? 'block' : 'none'; ?>">
                    <div class="form-row">
                        <label for="payment_instructions">Payment Instructions:</label>
                        <textarea id="payment_instructions" name="payment_instructions" rows="3"><?php echo htmlspecialchars($current_settings['payment_instructions']); ?></textarea>
                        <small>Instructions shown to customers for manual payment</small>
                    </div>
                </div>
                
                <!-- Stripe Section -->
                <div id="stripe-payment-section" class="conditional-section" style="display: <?php echo (isset($current_settings['enable_stripe_payment']) && $current_settings['enable_stripe_payment'] == '1') ? 'block' : 'none'; ?>">
                    <div class="form-row">
                        <label for="stripe_public_key">Stripe Public Key:</label>
                        <input type="text" id="stripe_public_key" name="stripe_public_key" value="<?php echo htmlspecialchars($current_settings['stripe_public_key']); ?>">
                    </div>
                    
                    <div class="form-row">
                        <label for="stripe_secret_key">Stripe Secret Key:</label>
                        <input type="password" id="stripe_secret_key" name="stripe_secret_key" value="<?php echo htmlspecialchars($current_settings['stripe_secret_key']); ?>">
                        <button type="button" class="toggle-password" data-target="stripe_secret_key">Show</button>
                    </div>
                    
                    <div class="form-row">
                        <label for="stripe_webhook_secret">Stripe Webhook Secret:</label>
                        <input type="password" id="stripe_webhook_secret" name="stripe_webhook_secret" value="<?php echo htmlspecialchars($current_settings['stripe_webhook_secret'] ?? ''); ?>">
                        <button type="button" class="toggle-password" data-target="stripe_webhook_secret">Show</button>
                        <small>Required for handling payment confirmations</small>
                    </div>
                </div>
                
                <!-- PayPal Section -->
                <div id="paypal-payment-section" class="conditional-section" style="display: <?php echo (isset($current_settings['enable_paypal_payment']) && $current_settings['enable_paypal_payment'] == '1') ? 'block' : 'none'; ?>">
                    <div class="form-row">
                        <label for="paypal_client_id">PayPal Client ID:</label>
                        <input type="text" id="paypal_client_id" name="paypal_client_id" value="<?php echo htmlspecialchars($current_settings['paypal_client_id']); ?>">
                    </div>
                    
                    <div class="form-row">
                        <label for="paypal_secret">PayPal Secret:</label>
                        <input type="password" id="paypal_secret" name="paypal_secret" value="<?php echo htmlspecialchars($current_settings['paypal_secret']); ?>">
                        <button type="button" class="toggle-password" data-target="paypal_secret">Show</button>
                    </div>
                </div>
                
                <!-- Bank Transfer Section -->
                <div id="bank-details-section" class="conditional-section" style="display: <?php echo (isset($current_settings['enable_bank_transfer']) && $current_settings['enable_bank_transfer'] == '1') ? 'block' : 'none'; ?>">
                    <div class="form-row">
                        <label for="bank_details">Bank Account Details:</label>
                        <textarea id="bank_details" name="bank_details" rows="4"><?php echo htmlspecialchars($current_settings['bank_details']); ?></textarea>
                        <small>Enter your bank details for customers to use for transfers</small>
                    </div>
                </div>
                
                <!-- WooCommerce Funds Section -->
                <div id="woo-funds-section" class="conditional-section" style="display: <?php echo (isset($current_settings['enable_woo_funds_payment']) && $current_settings['enable_woo_funds_payment'] == '1') ? 'block' : 'none'; ?>">
                    <div class="form-row">
                        <label for="woocommerce_site_url">WooCommerce Site URL:</label>
                        <input type="text" id="woocommerce_site_url" name="woocommerce_site_url" value="<?php echo htmlspecialchars($current_settings['woocommerce_site_url'] ?? WOO_SITE_URL); ?>">
                        <small>URL of your WooCommerce site (must include https://)</small>
                    </div>
                    
                    <div class="form-row">
                        <label for="woo_funds_api_key">WooCommerce Funds API Key:</label>
                        <input type="password" id="woo_funds_api_key" name="woo_funds_api_key" value="<?php echo htmlspecialchars($current_settings['woo_funds_api_key'] ?? ''); ?>">
                        <button type="button" class="toggle-password" data-target="woo_funds_api_key">Show</button>
                    </div>
                </div>
                
                <!-- GoCardless Section -->
                <div id="gocardless-section" class="conditional-section" style="display: <?php echo (isset($current_settings['enable_gocardless_payment']) && $current_settings['enable_gocardless_payment'] == '1') ? 'block' : 'none'; ?>">
                    <div class="form-row">
                        <label for="gocardless_access_token">GoCardless Access Token:</label>
                        <input type="password" id="gocardless_access_token" name="gocardless_access_token" value="<?php echo htmlspecialchars($current_settings['gocardless_access_token'] ?? ''); ?>">
                        <button type="button" class="toggle-password" data-target="gocardless_access_token">Show</button>
                    </div>
                    
                    <div class="form-row">
                        <label for="gocardless_environment">GoCardless Environment:</label>
                        <select id="gocardless_environment" name="gocardless_environment">
                            <option value="sandbox" <?php echo (isset($current_settings['gocardless_environment']) && $current_settings['gocardless_environment'] == 'sandbox') ? 'selected' : ''; ?>>Sandbox</option>
                            <option value="live" <?php echo (isset($current_settings['gocardless_environment']) && $current_settings['gocardless_environment'] == 'live') ? 'selected' : ''; ?>>Live</option>
                        </select>
                    </div>
                    
                    <div class="form-row">
                        <label for="gocardless_webhook_secret">GoCardless Webhook Secret:</label>
                        <input type="password" id="gocardless_webhook_secret" name="gocardless_webhook_secret" value="<?php echo htmlspecialchars($current_settings['gocardless_webhook_secret'] ?? ''); ?>">
                        <button type="button" class="toggle-password" data-target="gocardless_webhook_secret">Show</button>
                    </div>
                </div>
                
                <!-- Apple/Google Pay Section -->
                <div id="apple-google-pay-section" class="conditional-section" style="display: <?php echo (isset($current_settings['enable_apple_google_pay']) && $current_settings['enable_apple_google_pay'] == '1') ? 'block' : 'none'; ?>">
                    <div class="form-row">
                        <label for="apple_merchant_id">Apple Merchant ID:</label>
                        <input type="text" id="apple_merchant_id" name="apple_merchant_id" value="<?php echo htmlspecialchars($current_settings['apple_merchant_id'] ?? ''); ?>">
                        <small>Get this from your Apple Developer account</small>
                    </div>
                    
                    <div class="form-row">
                        <label for="google_merchant_id">Google Merchant ID:</label>
                        <input type="text" id="google_merchant_id" name="google_merchant_id" value="<?php echo htmlspecialchars($current_settings['google_merchant_id'] ?? ''); ?>">
                        <small>Get this from your Google Pay Business Console</small>
                    </div>
                    
                    <div class="note-box" style="background-color: #fff3cd; padding: 15px; border-radius: 4px; margin-top: 15px;">
                        <h4 style="margin-top: 0;">Important Notes for Apple/Google Pay</h4>
                        <ul>
                            <li>For Apple Pay, you need an Apple Developer account ($99/year)</li>
                            <li>You must verify domain ownership with Apple</li>
                            <li>For best results, use Stripe as your payment processor and enable Apple/Google Pay in your Stripe Dashboard</li>
                            <li>Stripe will automatically handle all the technical integration requirements</li>
                        </ul>
                    </div>
                </div>
            </div>
            
            <!-- Content Tab -->
            <div id="content-tab" class="tab-content <?php echo ($active_tab == 'content') ? 'active' : ''; ?>">
                <h3>Content Settings</h3>
                
                <div class="form-row">
                    <label for="header_text">Simple Header Text:</label>
                    <input type="text" id="header_text" name="header_text" value="<?php echo htmlspecialchars($current_settings['header_text']); ?>">
                    <small>Basic text to display in the header (for simple customization)</small>
                </div>
                
                <div class="form-row">
                    <label for="custom_header">Custom Header HTML:</label>
                    <textarea id="custom_header" name="custom_header" rows="6" class="code-editor"><?php echo htmlspecialchars($current_settings['custom_header']); ?></textarea>
                    <small>Add custom HTML code to be included in the page header (overrides simple header text)</small>
                </div>
                
                <div class="form-row">
                    <label for="footer_text">Simple Footer Text:</label>
                    <input type="text" id="footer_text" name="footer_text" value="<?php echo htmlspecialchars($current_settings['footer_text']); ?>">
                    <small>Basic text to display in the footer (for simple customization)</small>
                </div>
                
                <div class="form-row">
                    <label for="custom_footer">Custom Footer HTML:</label>
                    <textarea id="custom_footer" name="custom_footer" rows="6" class="code-editor"><?php echo htmlspecialchars($current_settings['custom_footer']); ?></textarea>
                    <small>Add custom HTML code to be included in the page footer (overrides simple footer text)</small>
                </div>
                
                <div class="form-row">
                    <label for="shop_description">Shop Description:</label>
                    <textarea id="shop_description" name="shop_description" rows="4"><?php echo htmlspecialchars($current_settings['shop_description']); ?></textarea>
                    <small>Brief description of your shop (used in metadata and social sharing)</small>
                </div>
                
                <div class="form-row">
                    <label for="custom_css">Custom CSS:</label>
                    <textarea id="custom_css" name="custom_css" rows="6"><?php echo htmlspecialchars($current_settings['custom_css']); ?></textarea>
                    <small>Add any custom CSS to further customize your shop</small>
                </div>

                <!-- Add this new QR Code section -->
                <div class="settings-section">
                    <h4>Shop QR Code</h4>
                    <p>This QR code can be printed and displayed in your physical store for customers to scan.</p>
                    
                    <div class="qr-code-container">
                        <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                        <input type="hidden" name="generate_qr" value="1">
                        
                        <div class="form-row">
                            <label for="shop_url">Shop URL:</label>
                            <input type="text" id="shop_url" name="shop_url" value="<?php 
                                echo htmlspecialchars(!empty($_POST['shop_url']) ? $_POST['shop_url'] : 
                                    (!empty($current_settings['shop_url']) ? $current_settings['shop_url'] : 
                                        (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https://' : 'http://') . $_SERVER['HTTP_HOST']
                                    )
                                ); 
                            ?>">
                            <small>URL that the QR code will link to</small>
                        </div>
                        
                        <div style="text-align: center; margin: 15px 0;">
                            <button type="button" id="regenerate-qr" class="button">Generate QR Code</button>
                        </div>
                        
                        <?php 
                        // Get the shop URL
                        $shop_url = !empty($_POST['shop_url']) ? $_POST['shop_url'] : 
                                    (!empty($current_settings['shop_url']) ? $current_settings['shop_url'] : 
                                        (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https://' : 'http://') . $_SERVER['HTTP_HOST']
                                    );
                        
                        // Create QR code URL using Google Charts API
                        $qr_url = "https://chart.googleapis.com/chart?cht=qr&chs=300x300&chl=" . urlencode($shop_url) . "&choe=UTF-8";
                        ?>
                        
                        <div class="qr-preview" style="margin: 20px 0; text-align: center;">
                            <img src="<?php echo $qr_url; ?>" alt="Shop QR Code" style="max-width: 300px; border: 1px solid #ddd;">
                        </div>
                        
                        <div class="form-actions" style="display: flex; gap: 10px; justify-content: center;">
                            <a href="<?php echo $qr_url; ?>" download="shop-qr-code.png" class="button">Download QR Code</a>
                        </div>
                        
                        <div class="notice-box info" style="margin-top: 20px;">
                            <p>
                                <strong>QR Code Usage Tips:</strong>
                            </p>
                            <ul>
                                <li>Print this QR code and place it in your physical store</li>
                                <li>Include it on signs, posters, or at your honor payment box</li>
                                <li>Customers can scan it with their phone camera to visit your shop</li>
                                <li>Use the form above to generate a new QR code if needed</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Users Tab -->
            <div id="users-tab" class="tab-content <?php echo ($active_tab == 'users') ? 'active' : ''; ?>">
                <h3>User Management</h3>
                
                <?php
                try {
                    // Check if the users table exists
                    $result = $db->query("SHOW TABLES LIKE 'users'");
                    $tableExists = ($result->rowCount() > 0);
                    
                    if (!$tableExists) {
                        echo '<div class="error-message">Users table does not exist. Please refresh this page to create it.</div>';
                    } else {
                        // Get users from database
                        $stmt = $db->query("SELECT * FROM users ORDER BY id");
                        $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
                ?>
                    <div class="user-management-section">
                        <h4>Current Users</h4>
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>Username</th>
                                    <th>Email</th>
                                    <th>Role</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (count($users) > 0): ?>
                                    <?php foreach ($users as $user): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($user['username']); ?></td>
                                            <td><?php echo htmlspecialchars($user['email']); ?></td>
                                            <td><?php echo htmlspecialchars($user['role']); ?></td>
                                            <td>
                                                <a href="edit-user.php?id=<?php echo $user['id']; ?>" class="button small">Edit</a>
                                                <a href="delete-user.php?id=<?php echo $user['id']; ?>" class="button small danger" onclick="return confirm('Are you sure you want to delete this user?')">Delete</a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="4">No users found</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                        
                        <h4>Add New User</h4>
                        <form method="post" action="">
                            <input type="hidden" name="action" value="add_user">
                            <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                            
                            <div class="form-row">
                                <label for="new_username">Username:</label>
                                <input type="text" id="new_username" name="new_username" required>
                            </div>
                            
                            <div class="form-row">
                                <label for="new_email">Email:</label>
                                <input type="email" id="new_email" name="new_email" required>
                            </div>
                            
                            <div class="form-row">
                                <label for="new_password">Password:</label>
                                <input type="password" id="new_password" name="new_password" required>
                            </div>
                            
                            <div class="form-row">
                                <label for="new_role">Role:</label>
                                <select id="new_role" name="new_role">
                                    <option value="admin">Admin</option>
                                    <option value="manager">Manager</option>
                                    <option value="staff">Staff</option>
                                </select>
                            </div>
                            
                            <button type="submit" name="add_user" class="button">Add User</button>
                        </form>
                    </div>
                <?php
                    } // End if table exists
                } catch (PDOException $e) {
                    echo '<div class="error-message">Error accessing users: ' . htmlspecialchars($e->getMessage()) . '</div>';
                }
                ?>
            </div>
            
            <!-- Order Logs Tab -->
            <div id="order_logs-tab" class="tab-content <?php echo ($active_tab == 'order_logs') ? 'active' : ''; ?>">
                <h3>Order Logs</h3>
                
                <?php
                try {
                    // Check if order_logs table exists
                    $result = $db->query("SHOW TABLES LIKE 'order_logs'");
                    $tableExists = ($result->rowCount() > 0);
                    
                    if (!$tableExists) {
                        echo '<div class="notice-box warning">Order logs table does not exist. No logs to display.</div>';
                    } else {
                        // Get recent order logs - adjust the query to match your actual table structure
                        $stmt = $db->query("SELECT 
                            ol.id,
                            ol.order_id,
                            ol.log_type,
                            ol.message,
                            ol.created_at,
                            IFNULL(o.customer_name, 'System') as customer_name,
                            IFNULL(o.total_amount, 0.00) as total_amount
                        FROM 
                            order_logs ol
                        LEFT JOIN 
                            orders o ON ol.order_id = o.id
                        ORDER BY 
                            ol.created_at DESC
                        LIMIT 100");
                        
                        $logs = $stmt->fetchAll(PDO::FETCH_ASSOC);
                ?>
                    <div class="log-filters">
                        <div class="form-row">
                            <label for="log-type-filter">Filter by Type:</label>
                            <select id="log-type-filter">
                                <option value="">All Types</option>
                                <option value="payment">Payment</option>
                                <option value="status">Status Change</option>
                                <option value="error">Error</option>
                                <option value="system">System</option>
                            </select>
                        </div>
                        <div class="form-row">
                            <label for="log-search">Search:</label>
                            <input type="text" id="log-search" placeholder="Search logs...">
                        </div>
                    </div>
                    
                    <table class="data-table logs-table">
                        <thead>
                            <tr>
                                <th>Date/Time</th>
                                <th>Order ID</th>
                                <th>Customer</th>
                                <th>Type</th>
                                <th>Message</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (count($logs) > 0): ?>
                                <?php foreach ($logs as $log): ?>
                                    <tr data-type="<?php echo htmlspecialchars($log['log_type']); ?>">
                                        <td><?php echo date('Y-m-d H:i:s', strtotime($log['created_at'])); ?></td>
                                        <td>
                                            <?php if (!empty($log['order_id'])): ?>
                                                <a href="view-order.php?id=<?php echo $log['order_id']; ?>">#<?php echo $log['order_id']; ?></a>
                                            <?php else: ?>
                                                -
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo htmlspecialchars($log['customer_name'] ?? 'N/A'); ?></td>
                                        <td>
                                            <span class="log-type <?php echo htmlspecialchars($log['log_type']); ?>">
                                                <?php echo ucfirst(htmlspecialchars($log['log_type'])); ?>
                                            </span>
                                        </td>
                                        <td><?php echo htmlspecialchars($log['message']); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="5">No logs found</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                <?php
                    } // End if table exists
                } catch (PDOException $e) {
                    echo '<div class="error-message">Error accessing logs: ' . htmlspecialchars($e->getMessage()) . '</div>';
                }
                ?>
            </div>
            
            <button type="submit" name="save_settings" class="save-settings-btn" formnovalidate>Save All Settings</button>
        </form>

<!-- Add needed CSS for tabs -->
<style>
    /* Improved Settings Tab Styling */
    .settings-tabs {
        display: flex;
        border-bottom: 2px solid #4CAF50;
        margin-bottom: 25px;
        background-color: #fff;
        border-radius: 5px 5px 0 0;
        overflow: hidden;
    }
    
    .settings-tab {
        padding: 12px 20px;
        cursor: pointer;
        background-color: #f9f9f9;
        color: #555;
        font-weight: 500;
        text-decoration: none;
        transition: all 0.3s ease;
        border-right: 1px solid #eee;
        text-align: center;
    }
    
    .settings-tab:last-child {
        border-right: none;
    }
    
    .settings-tab:hover {
        background-color: #f0f0f0;
        color: #4CAF50;
    }
    
    .settings-tab.active {
        background-color: #4CAF50;
        color: white;
        font-weight: 600;
        box-shadow: 0 -3px 5px rgba(0,0,0,0.05);
    }
    
    /* Tab Content Styling */
    .tab-content {
        display: none;
        padding: 25px;
        background-color: #fff;
        border-radius: 0 0 5px 5px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.05);
    }
    
    .tab-content.active {
        display: block;
        animation: fadeIn 0.3s ease;
    }
    
    /* Form Styling within Tabs */
    .tab-content h3 {
        color: #333;
        margin-top: 0;
        margin-bottom: 20px;
        padding-bottom: 10px;
        border-bottom: 1px solid #eee;
    }
    
    .form-row {
        margin-bottom: 15px;
    }
    
    .form-row label {
        display: block;
        margin-bottom: 5px;
        font-weight: 600;
        color: #444;
    }
    
    .form-row input[type="text"],
    .form-row input[type="email"],
    .form-row input[type="password"],
    .form-row input[type="number"],
    .form-row select,
    .form-row textarea {
        width: 100%;
        padding: 10px;
        border: 1px solid #ddd;
        border-radius: 4px;
        font-size: 14px;
        transition: border-color 0.2s;
    }
    
    .form-row input:focus,
    .form-row select:focus,
    .form-row textarea:focus {
        border-color: #4CAF50;
        outline: none;
    }
    
    /* Section Styling */
    .settings-section {
        margin-bottom: 30px;
        padding-bottom: 20px;
        border-bottom: 1px solid #eee;
    }
    
    .settings-section:last-child {
        border-bottom: none;
        margin-bottom: 0;
    }
    
    /* Fade-in Animation */
    @keyframes fadeIn {
        from { opacity: 0; }
        to { opacity: 1; }
    }
    
    .save-settings-btn {
        background-color: #4CAF50;
        color: white;
        padding: 12px 25px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        font-size: 16px;
        font-weight: 500;
        margin-top: 20px;
        transition: background-color 0.2s;
    }

    .save-settings-btn:hover {
        background-color: #45a049;
    }

    .message-container {
        margin-bottom: 20px;
    }

    .success-message {
        background-color: #dff0d8;
        color: #3c763d;
        border: 1px solid #d6e9c6;
        padding: 15px;
        border-radius: 4px;
    }

    .error-message {
        background-color: #f2dede;
        color: #a94442;
        border: 1px solid #ebccd1;
        padding: 15px;
        border-radius: 4px;
    }

    /* Log table styling */
    .logs-table .log-type {
        display: inline-block;
        padding: 3px 8px;
        border-radius: 3px;
        font-size: 12px;
        font-weight: 600;
        text-transform: uppercase;
    }

    .logs-table .log-type.payment {
        background-color: #dff0d8;
        color: #3c763d;
    }

    .logs-table .log-type.status {
        background-color: #d9edf7;
        color: #31708f;
    }

    .logs-table .log-type.error {
        background-color: #f2dede;
        color: #a94442;
    }

    .logs-table .log-type.system {
        background-color: #fcf8e3;
        color: #8a6d3b;
    }

    .log-filters {
        display: flex;
        margin-bottom: 20px;
        gap: 15px;
    }

    .log-filters .form-row {
        margin-bottom: 0;
        flex: 1;
    }
    
    .admin-wrapper {
        display: flex;
        flex-direction: column;
        min-height: 100vh;
    }

    .admin-content {
        flex: 1;
        padding: 0 20px 30px;
    }

    .admin-container {
        max-width: 1200px;
        margin: 0 auto;
    }

    /* QR Code styling */
    .qr-code-container {
        background-color: #f9f9f9;
        padding: 20px;
        border-radius: 6px;
        box-shadow: 0 1px 3px rgba(0,0,0,0.1);
    }

    .qr-preview img {
        box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        border-radius: 4px;
        transition: transform 0.2s;
    }

    .qr-preview img:hover {
        transform: scale(1.02);
    }

    .notice-box.info {
        background-color: #d9edf7;
        color: #31708f;
        border: 1px solid #bce8f1;
        padding: 15px;
        border-radius: 4px;
    }

    .notice-box ul {
        margin-top: 10px;
        margin-bottom: 0;
    }
</style>

<!-- Include the footer -->
<?php include 'includes/footer.php'; ?>

<!-- Add JavaScript for settings page functionality - REPLACE BOTH EXISTING SCRIPTS WITH THIS ONE -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    console.log("DOM loaded, initializing settings page...");
    
    // Tab functionality
    function setupTabs() {
        console.log("Setting up tabs...");
        
        var tabs = document.querySelectorAll('.settings-tab');
        var contents = document.querySelectorAll('.tab-content');
        
        tabs.forEach(function(tab) {
            tab.addEventListener('click', function(e) {
                e.preventDefault();
                
                console.log("Tab clicked:", this.getAttribute('href'));
                
                var tabName = this.getAttribute('href').replace('?tab=', '');
                history.pushState(null, '', '?tab=' + tabName);
                
                tabs.forEach(function(t) { t.classList.remove('active'); });
                contents.forEach(function(c) { 
                    c.classList.remove('active');
                    c.style.display = 'none';
                });
                
                this.classList.add('active');
                
                var content = document.getElementById(tabName + '-tab');
                if (content) {
                    content.classList.add('active');
                    content.style.display = 'block';
                    console.log("Activated tab:", tabName);
                } else {
                    console.error("Target tab not found:", tabName);
                }
            });
        });
    }
    
    // Initialize tabs
    setupTabs();
    
    // Make sure the active tab is visible initially
    var activeTab = document.querySelector('.tab-content.active');
    if (activeTab) {
        activeTab.style.display = 'block';
    }
    
    // Add data-controls attributes to checkboxes if missing
    var checkboxPairs = [
        { id: 'enable_manual', section: 'manual-payment-section' },
        { id: 'enable_stripe', section: 'stripe-payment-section' },
        { id: 'enable_paypal', section: 'paypal-payment-section' },
        { id: 'enable_bank_transfer', section: 'bank-details-section' },
        { id: 'enable_woo_funds', section: 'woo-funds-section' },
        { id: 'enable_gocardless', section: 'gocardless-section' },
        { id: 'enable_apple_google', section: 'apple-google-pay-section' }
    ];
    
    checkboxPairs.forEach(function(pair) {
        var checkbox = document.getElementById(pair.id);
        if (checkbox) {
            checkbox.setAttribute('data-controls', pair.section);
            console.log("Set data-controls for", pair.id, "to", pair.section);
            
            // Set initial state
            var section = document.getElementById(pair.section);
            if (section) {
                section.style.display = checkbox.checked ? 'block' : 'none';
                
                // Add change listener
                checkbox.addEventListener('change', function() {
                    section.style.display = this.checked ? 'block' : 'none';
                });
            }
        }
    });
    
    // Setup password toggle buttons
    document.querySelectorAll('.toggle-password').forEach(function(button) {
        button.addEventListener('click', function() {
            var targetId = this.getAttribute('data-target');
            var passwordField = document.getElementById(targetId);
            
            if (passwordField) {
                if (passwordField.type === 'password') {
                    passwordField.type = 'text';
                    this.textContent = 'Hide';
                } else {
                    passwordField.type = 'password';
                    this.textContent = 'Show';
                }
            }
        });
    });
    
    // Fix for Save Settings button - without changing any existing HTML structure
    var saveButton = document.querySelector('.save-settings-btn');
    if (saveButton) {
        console.log('Save button found, adding click handler');
        saveButton.addEventListener('click', function(e) {
            e.preventDefault(); // Prevent default submission
            console.log('Save button clicked');
            
            // Create a form to submit
            var form = document.createElement('form');
            form.method = 'post';
            form.action = window.location.href;
            form.style.display = 'none';
            
            // Hard-code important settings directly
            var settings = {
                'shop_name': document.getElementById('shop_name').value,
                'shop_organization': document.getElementById('shop_organization') ? document.getElementById('shop_organization').value : '',
                'currency_symbol': document.getElementById('currency_symbol') ? document.getElementById('currency_symbol').value : '$',
                'primary_color': document.getElementById('primary_color').value,
                'secondary_color': document.getElementById('secondary_color').value,
                'background_color': document.getElementById('background_color').value,
                'text_color': document.getElementById('text_color').value,
                'header_text': document.getElementById('header_text').value,
                'footer_text': document.getElementById('footer_text').value,
                'custom_header': document.getElementById('custom_header').value,
                'custom_footer': document.getElementById('custom_footer').value,
                'shop_description': document.getElementById('shop_description').value,
                'custom_css': document.getElementById('custom_css').value,
                'save_settings': '1'
            };
            
            // Add all settings to form
            for (var name in settings) {
                var input = document.createElement('input');
                input.type = 'hidden';
                input.name = name;
                input.value = settings[name];
                form.appendChild(input);
                console.log('Added setting:', name, '=', settings[name]);
            }
            
            // Add CSRF token
            var csrfInput = document.createElement('input');
            csrfInput.type = 'hidden';
            csrfInput.name = 'csrf_token';
            csrfInput.value = document.querySelector('input[name="csrf_token"]').value;
            form.appendChild(csrfInput);
            
            // Add payment settings checkboxes
            var paymentCheckboxes = [
                'enable_manual_payment', 
                'enable_stripe_payment', 
                'enable_paypal_payment', 
                'enable_bank_transfer', 
                'enable_woo_funds_payment',
                'enable_gocardless_payment',
                'enable_apple_google_pay'
            ];
            
            paymentCheckboxes.forEach(function(checkboxName) {
                var checkbox = document.querySelector('input[name="' + checkboxName + '"]');
                if (checkbox && checkbox.checked) {
                    var input = document.createElement('input');
                    input.type = 'hidden';
                    input.name = checkboxName;
                    input.value = '1';
                    form.appendChild(input);
                    console.log('Added checkbox:', checkboxName, '= 1');
                }
            });
            
            // Add payment settings fields
            var paymentFields = [
                'payment_instructions',
                'stripe_public_key',
                'stripe_secret_key',
                'stripe_webhook_secret',
                'paypal_client_id',
                'paypal_secret',
                'bank_details',
                'woocommerce_site_url',
                'woo_funds_api_key',
                'gocardless_access_token',
                'gocardless_environment',
                'gocardless_webhook_secret',
                'apple_merchant_id',
                'google_merchant_id'
            ];
            
            paymentFields.forEach(function(fieldName) {
                var field = document.getElementById(fieldName);
                if (field) {
                    var input = document.createElement('input');
                    input.type = 'hidden';
                    input.name = fieldName;
                    input.value = field.value;
                    form.appendChild(input);
                    console.log('Added field:', fieldName);
                }
            });
            
            // Add the form to the document and submit it
            document.body.appendChild(form);
            console.log('Form created with', form.elements.length, 'elements, submitting now');
            form.submit();
        });
    } else {
        console.error('Save button not found');
    }
    
    // Call this at the end of your DOMContentLoaded handler
    setupQRCodeGenerator();
});

// QR Code functionality - keep this function definition outside
function setupQRCodeGenerator() {
    console.log('Setting up QR code generator...');
    
    // Get elements directly since we know their IDs
    const shopUrlInput = document.getElementById('shop_url');
    const regenerateButton = document.getElementById('regenerate-qr');
    
    // Get other elements by their position in the DOM
    const qrPreview = document.querySelector('.qr-preview img');
    const downloadLink = document.querySelector('.form-actions a[download]');
    
    console.log('Checking QR code elements:');
    console.log('- shopUrlInput:', shopUrlInput ? 'Found' : 'Missing');
    console.log('- regenerateButton:', regenerateButton ? 'Found' : 'Missing');
    console.log('- qrPreview:', qrPreview ? 'Found' : 'Missing');
    console.log('- downloadLink:', downloadLink ? 'Found' : 'Missing');
    
    if (regenerateButton && shopUrlInput && qrPreview) {
        console.log('QR code elements found, setting up functionality');
        
        // Add click handler for regenerate button
        regenerateButton.addEventListener('click', function() {
            console.log('Regenerate QR button clicked');
            const shopUrl = shopUrlInput.value.trim();
            
            if (shopUrl) {
                console.log('Generating QR code for URL:', shopUrl);
                const newQrUrl = 'https://chart.googleapis.com/chart?cht=qr&chs=300x300&chl=' + 
                                encodeURIComponent(shopUrl) + '&choe=UTF-8';
                
                // Update the image source
                qrPreview.src = newQrUrl;
                
                // Update the download link if it exists
                if (downloadLink) {
                    downloadLink.href = newQrUrl;
                }
            } else {
                console.warn('Shop URL is empty, cannot generate QR code');
                alert('Please enter a URL for your shop before generating a QR code.');
            }
        });
    } else {
        console.error('Some QR code elements could not be found');
    }
}
</script>

<script>
// Simple QR Code Generator - standalone script
(function() {
    // Run this immediately when script loads
    document.addEventListener('DOMContentLoaded', function() {
        var shopUrlInput = document.getElementById('shop_url');
        var regenerateBtn = document.getElementById('regenerate-qr');
        var qrImage = document.querySelector('.qr-preview img');
        var downloadLink = document.querySelector('.qr-preview + .form-actions a');
        
        if (shopUrlInput && regenerateBtn && qrImage) {
            console.log('QR code elements found');
            
            regenerateBtn.addEventListener('click', function() {
                var url = shopUrlInput.value.trim();
                if (url) {
                    var qrUrl = 'https://chart.googleapis.com/chart?cht=qr&chs=300x300&chl=' + 
                               encodeURIComponent(url) + '&choe=UTF-8';
                    qrImage.src = qrUrl;
                    
                    if (downloadLink) {
                        downloadLink.href = qrUrl;
                    }
                    
                    console.log('QR code generated for: ' + url);
                } else {
                    alert('Please enter a URL for the QR code');
                }
            });
        } else {
            console.error('QR code generator: Missing required elements');
        }
    });
})();
</script>

<footer>
    <p>&copy; <?php echo date('Y'); ?> <?php echo htmlspecialchars($current_settings['shop_name'] ?? 'Self-Serve Shop'); ?>. All rights reserved.</p>
</footer>

<!-- Debug QR Code display -->
<div style="border: 1px solid #ddd; padding: 15px; margin: 20px 0;">
    <h4>QR Code Preview</h4>
    <?php
    $debug_shop_url = (!empty($current_settings['shop_url'])) ? 
                      $current_settings['shop_url'] : 
                      ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https://' : 'http://') . $_SERVER['HTTP_HOST']);
    $debug_qr_url = "https://chart.googleapis.com/chart?cht=qr&chs=300x300&chl=" . urlencode($debug_shop_url) . "&choe=UTF-8";
    ?>
    <div style="text-align: center;">
        <img src="<?php echo $debug_qr_url; ?>" alt="Shop QR Code" style="max-width: 300px; border: 1px solid #ddd;">
        <p>QR code for: <strong><?php echo htmlspecialchars($debug_shop_url); ?></strong></p>
        <div style="margin-top: 15px;">
            <a href="<?php echo $debug_qr_url; ?>" download="shop-qr-code.png" class="button">Download QR Code</a>
        </div>
    </div>
</div>