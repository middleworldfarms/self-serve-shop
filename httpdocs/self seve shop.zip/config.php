<?php
// Ensure proper character encoding
mb_internal_encoding('UTF-8');
if (!headers_sent()) {
    header('Content-Type: text/html; charset=utf-8');
}

// Prevent multiple inclusion
if (defined('CONFIG_LOADED')) {
    return;
}
define('CONFIG_LOADED', true);

// Database configuration
if (!defined('DB_TYPE')) define('DB_TYPE', 'wordpress');
if (!defined('DB_HOST')) define('DB_HOST', 'localhost');
if (!defined('DB_NAME')) define('DB_NAME', 'wp_hataa');
if (!defined('DB_USER')) define('DB_USER', 'wp_uxjrp');
if (!defined('DB_PASS')) define('DB_PASS', 'Szd4n!942');

// WordPress table prefix (only used in wordpress mode)
if (!defined('TABLE_PREFIX')) define('TABLE_PREFIX', 'WI9cFa_');

// Shop settings
if (!defined('CURRENCY_SYMBOL')) define('CURRENCY_SYMBOL', '£');
if (!defined('SHOP_NAME')) define('SHOP_NAME', 'Middle World Farm Shop');
if (!defined('SHOP_ORGANIZATION')) define('SHOP_ORGANIZATION', 'Middle World Farms CIC');
if (!defined('SHOP_LOGO')) define('SHOP_LOGO', '/uploads/test-image.jpg');
if (!defined('SHOP_URL')) define('SHOP_URL', 'https://self-serve-shop.middleworldfarms.org/');

// Payment settings
if (!defined('PAYMENT_PROVIDER')) define('PAYMENT_PROVIDER', 'manual');
if (!defined('PAYMENT_INSTRUCTIONS')) define('PAYMENT_INSTRUCTIONS', 'Please pay at the honor box.');
if (!defined('ENABLE_MANUAL_PAYMENT')) define('ENABLE_MANUAL_PAYMENT', true);
if (!defined('ENABLE_STRIPE_PAYMENT')) define('ENABLE_STRIPE_PAYMENT', false);
if (!defined('ENABLE_PAYPAL_PAYMENT')) define('ENABLE_PAYPAL_PAYMENT', false);
if (!defined('ENABLE_WOO_FUNDS_PAYMENT')) define('ENABLE_WOO_FUNDS_PAYMENT', false);
if (!defined('ENABLE_GOCARDLESS_PAYMENT')) define('ENABLE_GOCARDLESS_PAYMENT', false);
if (!defined('ENABLE_APPLE_PAY_PAYMENT')) define('ENABLE_APPLE_PAY_PAYMENT', false);
if (!defined('ENABLE_GOOGLE_PAY_PAYMENT')) define('ENABLE_GOOGLE_PAY_PAYMENT', false);
if (!defined('STRIPE_PUBLIC_KEY')) define('STRIPE_PUBLIC_KEY', '');
if (!defined('STRIPE_SECRET_KEY')) define('STRIPE_SECRET_KEY', '');
if (!defined('PAYPAL_CLIENT_ID')) define('PAYPAL_CLIENT_ID', '');
if (!defined('PAYPAL_SECRET')) define('PAYPAL_SECRET', '');
if (!defined('WOO_SITE_URL')) define('WOO_SITE_URL', 'https://middleworldfarms.org');
if (!defined('WOO_FUNDS_API_KEY')) define('WOO_FUNDS_API_KEY', '');
if (!defined('GOCARDLESS_ACCESS_TOKEN')) define('GOCARDLESS_ACCESS_TOKEN', '');
if (!defined('GOCARDLESS_ENVIRONMENT')) define('GOCARDLESS_ENVIRONMENT', 'sandbox');
if (!defined('GOCARDLESS_WEBHOOK_SECRET')) define('GOCARDLESS_WEBHOOK_SECRET', '');
if (!defined('BANK_DETAILS')) define('BANK_DETAILS', '');

// Brand settings
if (!defined('PRIMARY_COLOR')) define('PRIMARY_COLOR', '#4caf50');
if (!defined('SECONDARY_COLOR')) define('SECONDARY_COLOR', '#305a32');
if (!defined('ACCENT_COLOR')) define('ACCENT_COLOR', '#3de60f');
if (!defined('SHOP_ADDRESS')) define('SHOP_ADDRESS', 'Middle World Farm
Bardney Road
Washingbourgh
lincoln
LN4 1AQ');
if (!defined('SHOP_PHONE')) define('SHOP_PHONE', '01522 449610');
if (!defined('SHOP_EMAIL')) define('SHOP_EMAIL', 'middleworldfarms@gmail.com');
if (!defined('SHOP_DESCRIPTION')) define('SHOP_DESCRIPTION', 'ZTrue Farm to fork shop open 6 days a week 10am till 9 pm');
if (!defined('CUSTOM_HEADER')) define('CUSTOM_HEADER', '');
if (!defined('CUSTOM_FOOTER')) define('CUSTOM_FOOTER', '');

// Start session if not started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Helper function for currency display
if (!function_exists('display_currency')) {
    function display_currency($amount) {
        // Simple, direct approach to avoid encoding issues
        return '£' . number_format((float)$amount, 2);
    }
}

/**
 * Fixes image paths to consistently use admin/uploads directory
 * @param string $path The image path to normalize
 * @return string The normalized path
 */
function normalize_image_path($path) {
    if (empty($path)) {
        return 'admin/uploads/Shopping bag.png'; // Default image
    }
    
    // Extract just the filename from any path
    $filename = basename($path);
    
    // Return the standardized path
    return 'admin/uploads/' . $filename;
}

/**
 * Ensures all image paths use admin/uploads
 */
function get_image_path($path = '') {
    // For empty paths or paths that don't include an image file
    if (empty($path) || !preg_match('/\.(jpg|jpeg|png|gif)$/i', $path)) {
        return '/admin/uploads/Shopping bag.png';
    }
    
    // If already using admin/uploads, return as is
    if (strpos($path, '/admin/uploads/') === 0) {
        return $path;
    }
    
    // For any other path, extract filename
    $filename = basename($path);
    
    // Return standardized path
    return '/admin/uploads/' . $filename;
}
